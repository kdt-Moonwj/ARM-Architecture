#include "device_driver.h"
#define BASE  (500) //msec
static void Sys_Init(void)
{
	Clock_Init();
	LED_Init();
	Uart_Init(115200);
	Key_Poll_Init();

	SCB->VTOR = 0x08003000;
	SCB->SHCSR = 0;
}

extern volatile int Key_Value;
extern volatile int Uart1_Rx_In;
extern volatile int Uart1_Rx_Data;
extern volatile int TIM2_Expired;
extern volatile int TIM4_Expired;
extern volatile unsigned char c;
extern volatile int SysTick_Flag;

static void Buzzer_Beep(unsigned char tone, int duration)
{
	const static unsigned short tone_value[] = {261,277,293,311,329,349,369,391,415,440,466,493,523,554,587,622,659,698,739,783,830,880,932,987};

	TIM3_Out_Freq_Generation(tone_value[tone]);
	//TIM2_Delay(duration);
	TIM2_Repeat_Interrupt_Enable(1,duration);
	//TIM3_Out_Stop();
}

void Main(void)
{
	enum key{C1, C1_, D1, D1_, E1, F1, F1_, G1, G1_, A1, A1_, B1, C2, C2_, D2, D2_, E2, F2, F2_, G2, G2_, A2, A2_, B2};
	enum note{N16=BASE/4, N8=BASE/2, N4=BASE, N2=BASE*2, N1=BASE*4};
	const int song1[][2] = {{G1,N4},{G1,N4},{E1,N8},{F1,N8},{G1,N4},{A1,N4},{A1,N4},{G1,N2},{G1,N4},{C2,N4},{E2,N4},{D2,N8},{C2,N8},{D2,N2}};
	const char * note_name[] = {"C1", "C1#", "D1", "D1#", "E1", "F1", "F1#", "G1", "G1#", "A1", "A1#", "B1", "C2", "C2#", "D2", "D2#", "E2", "F2", "F2#", "G2", "G2#", "A2", "A2#", "B2"};

	int i=0;
	int music = 0;
	Sys_Init();
	TIM3_Out_Init();
    TIM4_Out_Init();
	Uart1_Printf("Timer Interrupt Test\n");

	Key_ISR_Enable(1);
	Uart1_RX_Interrupt_Enable(1);
	TIM4_Out_PWM_Generation(10000,1);
	//TIM2_Repeat_Interrupt_Enable(1,200);
	
	Buzzer_Beep(song1[i][0], song1[i][1]);
	i++;
	
	for(;;)
	{
		#if 0
		if()
		if(Uart1_Rx_In)
		{
			
			Uart1_Printf("%d",c);
		
			Uart1_Rx_In = 0;
		}
		#endif
	

		#if 1

		if(TIM2_Expired == 1)
		{
			Uart1_Printf("*");
			TIM3_Out_Stop();
			Uart1_Printf("%s ", note_name[song1[i][0]]);
			Buzzer_Beep(song1[i][0], song1[i][1]);
			//music = 1;
			i++;
			//music=0;
			TIM2_Expired =0;
			if(i==(sizeof(song1)/sizeof(song1[0]))) i=0;
		}
		
		#endif
		

	}
}
