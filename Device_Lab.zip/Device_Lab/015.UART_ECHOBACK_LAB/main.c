#include "device_driver.h"

static void Sys_Init(void)
{
	Clock_Init();  //72MHz
	LED_Init();
	Uart_Init(115200);  
	Key_Poll_Init();
} //  H/W 초기화

#if 0

void Main(void)
{
	Sys_Init();

	while(!(Macro_Check_Bit_Set(USART1->SR,7)==1));
	USART1->DR = 'A';
	while(!(Macro_Check_Bit_Set(USART1->SR,7)==1));
	USART1->DR = 'B';
	while(!(Macro_Check_Bit_Set(USART1->SR,7)==1));
	USART1->DR = 'C';

}
#endif
#if 1

void Main(void)
{
	Sys_Init();
	Uart_Printf("UART Echo-Back Test\n");

	for(;;)
	{
		char x;
		while(!(Macro_Check_Bit_Set(USART1->SR,5)));
		x=USART1->DR;
		while(!(Macro_Check_Bit_Set(USART1->SR,7)));
		USART1->DR=x;
	}
}
#endif
