#include "device_driver.h"

#define KEY_VALUE() Macro_Extract_Area(~GPIOB->ODR,0x3,6)

void Key_Poll_Init(void)
{
	Macro_Set_Bit(RCC->APB2ENR, 3);
	Macro_Write_Block(GPIOB->CRL, 0xff, 0x44, 24);
}

int Key_Get_Pressed(void)
{
	return KEY_VALUE();
}

void Key_Wait_Key_Released(void)
{
	#if 0
	for(;;)
	{
		int key = KEY_Value;
		if (!(key==0)) return;
	}
	#endif
	while( !(KEY_VALUE() == 0) );
	
}

int Key_Wait_Key_Pressed(void)
{
	#if 0
	int key = KEY_VALUE();
	for(;;)
	{
		if ((key==0)) return key;
	}
	#endif
	int key;
    while( !((key = KEY_VALUE()) != 0));
    return key;

}
