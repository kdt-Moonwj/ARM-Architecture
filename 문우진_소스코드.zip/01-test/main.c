#include "device_driver.h"
static void Buzzer_Beep(unsigned char tone, int duration);
unsigned int get_random_timer(void);
#define LCDW			(320)
#define LCDH			(240)
#define X_MIN	 		(0)
#define X_MAX	 		(LCDW - 1)
#define Y_MIN	 		(0)
#define Y_MAX	 		(LCDH - 1)

#define TIMER_PERIOD	(10)
#define RIGHT			(1)
#define LEFT			(-1)
#define HOME			(0)
#define SCHOOL			(1)


#define UFO_STEP		(1)
#define CAR_STEP		(1)
#define Bullet_STEP		(20)

#define MISSILE_STEP	(5)
#define CAR_SIZE_X		(2)
#define CAR_SIZE_Y		(2)

#define FROG_STEP		(10)
#define BOSS_STEP   4 

#define FROG_SIZE_X		(20)
#define FROG_SIZE_Y		(20)

#define Bullet_SIZE_X	(3)
#define Bullet_SIZE_Y	(3)

#define UFO_COLOR		(4)
#define BACK_COLOR		(5)
#define CAR_COLOR		(0)
#define FROG_COLOR		(2)
#define Bullet_COLOR	(3)
#define BULLET_COLOR	(3)

#define GAME_OVER		(1)
#define UFO_WIDTH		(20)
#define UFO_HEIGHT		(20)
#define BULLET_OFFSET  10
int game_over;
typedef struct
{
	int x,y;
	int w,h;
	int ci;
	int dir;
}QUERY_DRAW;

#define MAX_BULLETS 500
#define ITEM_TYPE_HEALTH   0  // 체력 회복 아이템
#define ITEM_TYPE_GAGE     1  // 게이지 충전 아이템
#define ITEM_TYPE_POWERUP  2  // 총알 강화 아이템


extern tImage img2;
extern tImage bossufo;
extern tImage ufo0;
extern tImage item1;
extern tImage b1;
extern tImage missile3;
extern tImage clear0;
typedef struct {
    int x, y;       
    int w, h;      
    int type;       
    int active;     
    int dx, dy;
} Item;

#define MAX_ITEMS 10
#define ITEM_WIDTH  25
#define ITEM_HEIGHT 25
#define ITEM_SPEED 2
Item items[MAX_ITEMS];  

void Drop_Item(int x, int y, int type) {
    int i;
    for (i = 0; i < MAX_ITEMS; i++) {
        if (!items[i].active) { 
            items[i].x = x;
            items[i].y = y;
            items[i].w = ITEM_WIDTH;
            items[i].h = ITEM_HEIGHT;
            items[i].type = type;
            items[i].active = 1;
            items[i].dx = (get_random_timer() & 1) ? ITEM_SPEED : -ITEM_SPEED;
            items[i].dy = (get_random_timer() & 2) ? ITEM_SPEED : -ITEM_SPEED;
            break;
        }
    }
}
typedef struct {
    int x, y;
	int w,h;
    int active;
    
} BULLET;

BULLET bullets[MAX_BULLETS] = {0};


static QUERY_DRAW car;
static QUERY_DRAW frog;
static QUERY_DRAW bullet;

typedef struct {
    float x, y;      
    float dx, dy;    
    int active;
} UFO_BULLET;
const int DX[3] = { -5, -5, -5 };
const int DY[3] = { -2, 0, 2 };
#define MAX_UFO_BULLETS 100 
UFO_BULLET ufo_bullets[MAX_UFO_BULLETS] = {0};

static int score;
int gage;
static int frog_hp;
static unsigned short color[] = {RED, YELLOW, GREEN, BLUE, WHITE, BLACK};

static int Check_Collision(void)
{
	int col = 0;

	if((car.x >= frog.x) && ((frog.x + FROG_STEP) >= car.x)) col |= 1<<0;
	else if((car.x < frog.x) && ((car.x + CAR_STEP) >= frog.x)) col |= 1<<0;
	
	if((car.y >= frog.y) && ((frog.y + FROG_STEP) >= car.y)) col |= 1<<1;
	else if((car.y < frog.y) && ((car.y + CAR_STEP) >= frog.y)) col |= 1<<1;

	if(game_over==1)
	{
		Uart_Printf("SCORE = %d\n", score);	
        game_over=0;
		return GAME_OVER;
	}

	if((frog.dir == SCHOOL) && (frog.y == Y_MIN)) 
	{
		//Uart_Printf("SCHOOL\n");		
		frog.dir = HOME;
	}

	if((frog.dir == HOME) && (frog.y == LCDH - frog.h))
	{
		frog.dir = SCHOOL;
		score++;
		//Uart_Printf("HOME, %d\n", score);
		//Lcd_Printf(0,0,BLUE,WHITE,2,2,"%d", score);
	}

	return 0;
}


static int Car_Move(void)
{
	car.x += CAR_STEP * car.dir;

	if((car.x + car.w >= X_MAX) || (car.x <= X_MIN)) car.dir = -car.dir;
	else if(car.x>=frog.x) car.dir = -car.dir;
	else if(car.y>=frog.y) car.dir = -car.dir;

	if(car.x<=frog.x) car.x+=CAR_STEP;
	else if(car.x>=frog.x) car.x-=CAR_STEP;

	if(car.y<=frog.y) car.y+=CAR_STEP;
	else if(car.y>=frog.y) car.y-=CAR_STEP;

	return Check_Collision();
}

unsigned int get_random_timer(void)
{
    unsigned int t1 = TIM4->CNT;
    unsigned int t2 = TIM2->CNT;
    unsigned int t3 = SysTick->VAL;
    unsigned int t;

    t = t1 ^ (t2 << 7) ^ (t3 >> 2) ^ (t1 << 13);
    t += (t2 >> 5) + (t3 << 9);
    t ^= (t >> 11);

    t ^= (t << 5);
    t ^= (t >> 9);

    return t;
}

#if 1

static int bullet_Move(void)
{
	bullet.x+=Bullet_STEP;
	return Check_Collision();
}
#endif


static void k0(void)
{
	if(frog.y > Y_MIN) frog.y -= FROG_STEP;
}

static void k1(void)
{
	if(frog.y + frog.h < Y_MAX) frog.y += FROG_STEP;
}

static void k2(void)
{
	if(frog.x > X_MIN) frog.x -= FROG_STEP;
}

static void k3(void)
{
	if(frog.x + frog.w < X_MAX) frog.x += FROG_STEP;
}
#if 0
static int Frog_Move(int k)
{
	// UP(0), DOWN(1), LEFT(2), RIGHT(3)
	static void (*key_func[])(void) = {k0, k1, k2, k3};
	if(k <= 3) key_func[k]();
	return Check_Collision();
}
#endif
static void Frog_Move(int k)
{
	// UP(0), DOWN(1), LEFT(2), RIGHT(3)
	static void (*key_func[])(void) = {k0, k1, k2, k3};
	if(k <= 3) key_func[k]();
	
}

static void Game_Init(void)
{
	score = 0;
	Lcd_Clr_Screen();
	frog.x = 0; frog.y = 30; frog.w = FROG_SIZE_X; frog.h = FROG_SIZE_Y; frog.ci = FROG_COLOR; frog.dir = SCHOOL;
	//car.x = 320; car.y = 110; car.w = CAR_SIZE_X; car.h = CAR_SIZE_Y; car.ci = CAR_COLOR; car.dir = LEFT;
	//Lcd_Draw_Box(frog.x, frog.y, frog.w, frog.h, color[frog.ci]);
    draw_image(frog.x, frog.y, &img2);
	//Lcd_Draw_Box(car.x, car.y, car.w, car.h, color[car.ci]);

}
#define BULLET_WIDTH   3 
#define BULLET_HEIGHT  3 
#define MAX_UFO  100  

typedef struct {
	int x,y;
	int w,h;
	int ci;
    int active;
} UFO;

static UFO ufos[MAX_UFO];  

typedef struct {
    int x, y;
    int w, h;
    int active;
    int dx, dy;   
} BossMissile;

#define MAX_BOSS_MISSILES 30
static BossMissile boss_missiles[MAX_BOSS_MISSILES];



typedef struct {
    int x, y;           
    int w, h; 
    int hp;             
    int active;         
	int dir_y;
} BossUFO;

static BossUFO boss;
void Erase_Bullet_Trail(int x1, int x2, int y) {
    int min_x = x1 < x2 ? x1 : x2;
    int max_x = x1 > x2 ? x1 : x2;
    int xi, yi;
    for (xi = min_x; xi <= max_x; xi++) {
        for (yi = 0; yi < BULLET_HEIGHT; yi++) {
           
            if (xi >= frog.x && xi < frog.x + frog.w &&         // FROG_WIDTH: frog 크기
                y + yi >= frog.y && y + yi < frog.y + frog.h)  // FROG_HEIGHT: frog 크기
            {
                //Lcd_Draw_Box(xi, y + yi,BULLET_WIDTH ,BULLET_HEIGHT,color[FROG_COLOR]);
                draw_image(frog.x, frog.y, &img2);
            } else {
                Lcd_Draw_Box(xi, y + yi,BULLET_WIDTH ,BULLET_HEIGHT,color[BACK_COLOR]);
            }
        }
    }
}
static void Draw_Object(QUERY_DRAW * obj)
{
	Lcd_Draw_Box(obj->x, obj->y, obj->w, obj->h, color[obj->ci]);
}
static void Draw_Object_Bullet(BULLET * obj, int x)
{
	Lcd_Draw_Box(obj->x, obj->y,3,3, color[x]);
}
static void Draw_Object_UFO(UFO * obj, int x)
{
	Lcd_Draw_Box(obj->x, obj->y,30,20, color[x]);
}
static void Draw_Object_UFO_Bullet(UFO_BULLET * obj, int color_idx)
{
    Lcd_Draw_Box((int)obj->x, (int)obj->y, 3, 3, color[color_idx]);
}
static void Draw_BossUFO(BossUFO * obj, int color_idx)
{
    Lcd_Draw_Box(obj->x, obj->y, obj->w, obj->h, color[color_idx]);
}
static void Draw_Object_BossMissile(BossMissile * obj, int color_idx)
{
    Lcd_Draw_Box((int)obj->x, (int)obj->y, obj->w, obj->h, color[color_idx]);
}
static void Draw_Item(Item * obj, int color_idx)
{
    Lcd_Draw_Box((int)obj->x, (int)obj->y, obj->w, obj->h, color[color_idx]);
}

extern volatile int TIM4_expired;
extern volatile int USART1_rx_ready;
extern volatile int USART1_rx_data;
extern volatile int Jog_key_in;
extern volatile int Jog_key;
extern volatile int bullet_request;
extern volatile int bullet_active;
extern volatile int Move_key;

void System_Init(void)
{
	Clock_Init();
	LED_Init();
	Key_Poll_Init();
	Uart1_Init(115200);

	SCB->VTOR = 0x08003000;
	SCB->SHCSR = 7<<16;
}
#define SIGN(x) ((x)<0?-1:1)
void Boss_Fire_Missile(int boss_x, int boss_y)
{
	int i;
    for(i=0; i<MAX_BOSS_MISSILES; i++) {
        if(!boss_missiles[i].active) {
            BossMissile *m = &boss_missiles[i];
            m->x = boss_x;
            m->y = boss_y;
            m->w = 20;
            m->h = 16;
            m->active = 1;
            break;
        }
    }
}
int bullet_powerup_level =0;
void Fire_Bullet_From_Frog(void)
{
    int i,j;

    int x_arr[3], y_arr[3], n = 1, fired = 0;
    x_arr[0] = frog.x; y_arr[0] = frog.y;
    if (bullet_powerup_level >= 1) 
    { 
        x_arr[n] = frog.x; y_arr[n++] = frog.y - BULLET_OFFSET; 
    }
    if (bullet_powerup_level >= 2) 
    { 
        x_arr[n] = frog.x; y_arr[n++] = frog.y + BULLET_OFFSET; 
    }

    
    for (j = 0; j < n; j++) {
        for (i = 0; i < MAX_BULLETS; i++) {
            if (!bullets[i].active) {
                bullets[i].x = x_arr[j];
                bullets[i].y = y_arr[j];
                bullets[i].active = 1;
               
                fired = 1;
                break; 
            }
        }
    }
    
}
void Clear_All_UFO_and_Bullets(void)
{
    int i;
    for(i=0; i<MAX_UFO; i++)
        ufos[i].active = 0;

    for(i=0; i<MAX_UFO_BULLETS; i++)
        ufo_bullets[i].active = 0;
    for (i = 0; i < MAX_BOSS_MISSILES; i++)
        boss_missiles[i].active =0;
    for (i = 0; i <MAX_BULLETS; i++)
        bullets[i].active=0;
    
    boss.active = 0;     

}
void Spawn_New_UFO(void)
{
    int i;
    for(i=0; i<MAX_UFO; i++) {
        if(!ufos[i].active) {
            ufos[i].x = 310;
            ufos[i].y = (get_random_timer() % (180))+20;
            ufos[i].active = 1;
            break;
        }
    }
}

#define MISSILE_ERASE_MARGIN 4

void Erase_BossMissile_Wide(BossMissile* m) {
    
    int x = m->x - MISSILE_ERASE_MARGIN;
    int y = m->y - MISSILE_ERASE_MARGIN;
    int w = m->w + 2*MISSILE_ERASE_MARGIN;
    int h = m->h + 2*MISSILE_ERASE_MARGIN;

    if(x < 0) x = 0;
    if(y < 0) y = 0;
    if(x + w > LCDW) w = LCDW - x;
    if(y + h > LCDH) h = LCDH - y;

    Lcd_Draw_Box(x, y, w, h, color[5]);
}

void Wait_For_Stage_Up_Key(void)
{
    TIM3_Out_Stop();
    Lcd_Draw_Back_Color(BLACK);
    Lcd_Printf(60,60,RED,BLACK,2,2,"Next Stage");
    Lcd_Printf(20,130,RED,BLACK,2,2,"Press Key : SW1");
   
    while(!(Jog_key==5)); 
    Lcd_Draw_Back_Color(BLACK);
    
}
static int stage;
void Check_Bullet_UFO_Collisions(
    BULLET* bullets, int bullet_count,
    UFO* ufos, int ufo_count,
    BossUFO* boss,
    BossMissile* boss_missiles, int max_boss_missiles
)
{
    int i, j;
    for (i = 0; i < bullet_count; i++) 
	{
        if (!bullets[i].active) continue;
        int old_x = bullets[i].x - Bullet_STEP; 
        int new_x = bullets[i].x;               

        int left = (old_x < new_x) ? old_x : new_x;
        int right = (old_x > new_x) ? old_x : new_x;

        for (j = 0; j < ufo_count; j++) {
            if (!ufos[j].active) continue;
            
            int ufo_left   = ufos[j].x;
            int ufo_right  = ufos[j].x + UFO_WIDTH;
            int ufo_top    = ufos[j].y;
            int ufo_bottom = ufos[j].y + UFO_HEIGHT;

            if (
                right > ufo_left && left < ufo_right &&  
                bullets[i].y >= ufo_top && bullets[i].y < ufo_bottom 
            ) {
                Draw_Object_Bullet(&bullets[i], BACK_COLOR);
                Draw_Object_UFO(&ufos[j], BACK_COLOR);
                score++;
				gage++;
                Uart_Printf("score :%d\n", score);
                if ((get_random_timer() % 10) == 1) { 
                    int type = get_random_timer() % 4; 
                    Drop_Item(ufos[j].x, ufos[j].y, type); 
                }
                bullets[i].active = 0;
                ufos[j].active = 0;
                break; 
            }

        }

		if (boss && boss->active) {
            int boss_left   = boss->x;
            int boss_right  = boss->x + boss->w;
            int boss_top    = boss->y;
            int boss_bottom = boss->y + boss->h;
            if (
                right > boss_left && left < boss_right &&
                bullets[i].y >= boss_top && bullets[i].y < boss_bottom
            ) {
                Draw_Object_Bullet(&bullets[i], BACK_COLOR);
                bullets[i].active = 0;

                boss->hp--;
                Uart_Printf("Boss HP: %d\n", boss->hp);

                if (boss->hp <= 0) {
                    boss->active = 0;
                    score+=10;
                    Draw_BossUFO(boss, BACK_COLOR); 
                    Uart_Printf("Boss destroyed!\n");
                    
                    stage++;
                    Clear_All_UFO_and_Bullets();
                    Wait_For_Stage_Up_Key();
                    frog.x = 0; frog.y = 30;
                    frog.ci = FROG_COLOR;
                    //Draw_Object(&frog);
                    draw_image(frog.x, frog.y, &img2);
                    
                }
            }
        }

        for (j = 0; j < max_boss_missiles; j++) {
            if (!boss_missiles[j].active) continue;
            int m_left   = boss_missiles[j].x;
            int m_right  = boss_missiles[j].x + boss_missiles[j].w;
            int m_top    = boss_missiles[j].y;
            int m_bottom = boss_missiles[j].y + boss_missiles[j].h;
            
            if (
                right > m_left && left < m_right &&
                bullets[i].y >= m_top && bullets[i].y < m_bottom
            ) {
                Draw_Object_Bullet(&bullets[i], BACK_COLOR);
                
                Draw_Object_UFO(&boss_missiles[j], BACK_COLOR);
                bullets[i].active = 0;
                boss_missiles[j].active = 0;
                break;
            }
        }


    }
}
#if 0
void Check_Bullet_UFO_Collisions(BULLET* bullets, int bullet_count, UFO* ufos, int ufo_count)
{
	int i,j;
    for (i = 0; i < bullet_count; i++) {
        if (!bullets[i].active) continue;
        for (j = 0; j < ufo_count; j++) {
            if (!ufos[j].active) continue;
            if (bullets[i].x >= ufos[j].x && bullets[i].x < ufos[j].x + UFO_WIDTH &&
                bullets[i].y >= ufos[j].y && bullets[i].y < ufos[j].y + UFO_HEIGHT) {
                // 겹치면 양쪽 모두 배경색으로 지움 + 비활성화
                Draw_Object_Bullet(&bullets[i], BACK_COLOR);
                Draw_Object_UFO(&ufos[j], BACK_COLOR);
				score++;
				Uart_Printf("score :%d\n", score);
				Lcd_Printf(0,0,RED,BLACK,1,1,"score : %d", score);
                bullets[i].active = 0;
                ufos[j].active = 0;
            }
        }
    }
}
#endif

void Create_BossUFO(void)
{
    boss.x = (LCDW - 60);           
    boss.y = 100;                       
    boss.w = 40;
    boss.h = 50;
    boss.hp = 10;                      
    boss.active = 1;                    
	boss.dir_y = +1;
    
}

void Move_And_Draw_UFOs(UFO* ufos, int count) {
	int i;
    for (i = 0; i < count; i++) {
        if (ufos[i].active) {
           
            Draw_Object_UFO(&ufos[i], BACK_COLOR);

          
            ufos[i].x -= UFO_STEP;

            if (ufos[i].x < 0) {
                ufos[i].active = 0;
            } else {
                
                //Draw_Object_UFO(&ufos[i], UFO_COLOR);
                draw_image(ufos[i].x, ufos[i].y, &ufo0);
            }
        }
    }
}

void Move_And_Draw_BossUFO(BossUFO *boss) 
{
    if (!boss->active) return;  

    Draw_BossUFO(boss, BACK_COLOR);

    boss->y += (boss->dir_y * BOSS_STEP);

    if (boss->y <= 20) {
        boss->y = 20;
        boss->dir_y = +1;
    } else if (boss->y + boss->h >= 220) {
        boss->y = 220 - boss->h;
        boss->dir_y = -1;
    }

    draw_image(boss->x, boss->y, &bossufo);
}

void UFO_Fire_Bullets(int ufo_x, int ufo_y)
{
    int pattern = get_random_timer() % 6; 
    int seq[3];

    switch(pattern) 
	{
    case 0: seq[0]=0; seq[1]=1; seq[2]=2; break;
    case 1: seq[0]=0; seq[1]=2; seq[2]=1; break;
    case 2: seq[0]=1; seq[1]=0; seq[2]=2; break;
    case 3: seq[0]=1; seq[1]=2; seq[2]=0; break;
    case 4: seq[0]=2; seq[1]=0; seq[2]=1; break;
    default:seq[0]=2; seq[1]=1; seq[2]=0; break;
    }
	int k,j;
    for(k=0; k<3; k++) {
        for(j=0; j<MAX_UFO_BULLETS; j++) {
            if (!ufo_bullets[j].active) {
                ufo_bullets[j].x = ufo_x;
                ufo_bullets[j].y = ufo_y;
                ufo_bullets[j].dx = DX[seq[k]];
                ufo_bullets[j].dy = DY[seq[k]];
                ufo_bullets[j].active = 1;
                break;
            }
        }
    }
}


void Move_And_Draw_Items(Item* items, int count) {
    int i;
    for (i = 0; i < count; i++) {
        if (!items[i].active) continue;

        Draw_Item(&items[i], BACK_COLOR);

        items[i].x += items[i].dx;
        items[i].y += items[i].dy;

        if (items[i].x < X_MIN) {
            items[i].x = X_MIN;
            items[i].dx = -items[i].dx;
        } else if (items[i].x > 290) {
            items[i].x = 290;
            items[i].dx = -items[i].dx;
        }

        if (items[i].y < Y_MIN) {
            items[i].y = Y_MIN;
            items[i].dy = -items[i].dy;
        } else if (items[i].y > 220) {
            items[i].y = 220;
            items[i].dy = -items[i].dy;
        }

        draw_image(items[i].x, items[i].y, &item1);
    }
}
void Check_Frog_Item_Collision_and_Apply(Item* items, int count)
{
    int i;
    for (i = 0; i < count; i++) {
        if (!items[i].active) continue;

        if (frog.x < items[i].x + items[i].w &&
            frog.x + frog.w > items[i].x &&
            frog.y < items[i].y + items[i].h &&
            frog.y + frog.h > items[i].y) {

            #if 1
            if (items[i].type == ITEM_TYPE_HEALTH) {
                frog_hp++; 
            } else if (items[i].type == ITEM_TYPE_GAGE) {
                gage += 5; 
            } else if ((items[i].type == 2)||(items[i].type == 3)) {
                if (bullet_powerup_level < 2)
                    bullet_powerup_level++;      // 
                else
                    score += 20;          
            }
            #endif
         

            // 3. 아이템 사라지게 처리
            Draw_Item(&items[i], BACK_COLOR);   
            items[i].active = 0;               
        }
    }
}


void Move_And_Draw_Bullets(BULLET* bullets, int count) {
	int i;
    for (i = 0; i < count; i++) {
        if (bullets[i].active) {
            int old_x = bullets[i].x;
            int old_y = bullets[i].y;

			int new_x = bullets[i].x + Bullet_STEP;
			if (new_x >= X_MAX) {
				
				Erase_Bullet_Trail(old_x, X_MAX, old_y);
				bullets[i].x = X_MAX; 
				bullets[i].active = 0; 
				continue; 
			} else {
				Erase_Bullet_Trail(old_x, new_x, old_y);
				bullets[i].x = new_x;
				Draw_Object_Bullet(&bullets[i], CAR_COLOR);
			}
        }
    }
}
int Check_Frog_BossMissile_Collision(QUERY_DRAW* frog, BossMissile* m)
{
    return (frog->x < m->x + m->w &&
            frog->x + frog->w > m->x &&
            frog->y < m->y + m->h &&
            frog->y + frog->h > m->y);
}

int Check_Frog_UFO_Bullet_Collision(QUERY_DRAW* f, UFO_BULLET* b)
{
    int dx = f->x - b->x;
    int dy = f->y - b->y;
    int dist2 = dx*dx + dy*dy;
    int min_dist = 6;
    return (dist2 < min_dist*min_dist);
}
void Move_And_Draw_BossMissiles(BossMissile* missiles, int count)
{
    int i;
    for(i = 0; i < count; i++) {
        if(missiles[i].active) {
            Draw_Object_BossMissile(&missiles[i], BACK_COLOR);

            if(missiles[i].x < frog.x)
                missiles[i].x += MISSILE_STEP;
            else if(missiles[i].x > frog.x)
                missiles[i].x -= MISSILE_STEP;

            if(missiles[i].y < frog.y)
                missiles[i].y += MISSILE_STEP;
            else if(missiles[i].y > frog.y)
                missiles[i].y -= MISSILE_STEP;

            if (Check_Frog_BossMissile_Collision(&frog, &missiles[i])) {
                missiles[i].active = 0;
				Draw_Object_BossMissile(&missiles[i], BACK_COLOR);
                frog.ci = FROG_COLOR;
				//Draw_Object(&frog);
                draw_image(frog.x, frog.y, &img2);
                frog_hp--;
                Uart_Printf("Frog HP: %d\n", frog_hp);
                continue;
            }

            if(missiles[i].x < X_MIN || missiles[i].x + missiles[i].w > X_MAX ||
               missiles[i].y < Y_MIN || missiles[i].y + missiles[i].h > Y_MAX) {
                missiles[i].active = 0;
            } else {
                //Draw_Object_BossMissile(&missiles[i], 2);
                draw_image(missiles[i].x, missiles[i].y, &missile3);
            }
        }
    }
}




void Move_And_Draw_UFO_Bullets(UFO_BULLET* bullets, int count)
{
    int i;
    for(i = 0; i < count; i++) {
        if(bullets[i].active) {
            Draw_Object_UFO_Bullet(&bullets[i], BACK_COLOR);

            // 위치 이동
            bullets[i].x += bullets[i].dx;
            bullets[i].y += bullets[i].dy;

            if(bullets[i].x < X_MIN || bullets[i].x > X_MAX ||
               bullets[i].y < Y_MIN || bullets[i].y > Y_MAX) {
                bullets[i].active = 0;
                continue;
            }

			if (Check_Frog_UFO_Bullet_Collision(&frog, &bullets[i])) {
				Draw_Object_UFO_Bullet(&bullets[i], BACK_COLOR);
				frog.ci = FROG_COLOR;
				//Draw_Object(&frog);
                draw_image(frog.x, frog.y, &img2);
				frog_hp--;
				bullets[i].active = 0;
				Uart_Printf("Frog HP: %d\n", frog_hp);
                if(frog_hp <= 0) 
                {
                    game_over = 1;
                }
                continue; 
            }

            Draw_Object_UFO_Bullet(&bullets[i], BULLET_COLOR);
        }
    }
}

extern volatile int TIM2_Expired;
extern volatile int SysTick_Flag;
#define BASE  (400) //msec
#define DIPLAY_MODE		3

static void Buzzer_Beep(unsigned char tone, int duration)
{
	const static unsigned short tone_value[] = {261,277,293,311,329,349,369,391,415,440,466,493,523,554,587,622,659,698,739,783,830,880,932,987};

	TIM3_Out_Freq_Generation(tone_value[tone]);
	
	TIM2_Repeat_Interrupt_Enable(1,duration);
	
}

void Main(void)
{
    enum key {
        C1, C1_, D1, D1_, E1, F1, F1_, G1, G1_, A1, A1_, B1, 
        C2, C2_, D2, D2_, E2, F2, F2_, G2, G2_, A2, A2_, B2, 
        REST
    };
    enum note {N16 = BASE/4, N8 = BASE/2, N4 = BASE, N2 = BASE*2, N1 = BASE*4};
    
	const int BGM_melody[][2] = {
           
        {C2,N8}, {A1,N8}, {B1,N8}, {C2,N8}, {F2,N8}, {C2,N8}, {A1,N8}, {B1,N8}, {C1,N8}, {F2,N8}, {F2,N16}, {A1,N8},
        // *레 라 파 라 *레 라 미 라 시 *미 라 시 *미 솔# 시 *미 #솔 *시 *솔 *미 시 라 -
        {D2,N8}, {A1,N8}, {F1,N8}, {A1,N8}, {D2,N8}, {A1,N8}, {E1,N8}, {A1,N8}, {B1,N8}, {E2,N8}, {A1,N8}, {B1,N8}, {E2,N8}, {G1_,N8}, {B1,N8}, {E2,N8}, {G2_,N8}, {B2,N8}, {G2,N8}, {E2,N8}, {B1,N8}, {A1,N8}, {A1,N16},
    
        // 솔 라 *도 - 솔 라 - 도 라 솔# 파 솔 라 *도 라
        {G1,N8},{A1,N8},{C2,N8},{C2,N16},{G1,N8},{A1,N8},{A1,N16},{C1,N8},{A1,N8},{G1_,N8},{F1,N8},{G1,N8},{A1,N8},{C2,N8},{A1,N8},  {A1, N8}, {A1,N16}, {G1,N8}, {A1,N8},
        // *도-솔라*도
        {C2, N8}, {C2, N16}, {G1,N8}, {A1,N8}, {C2,N8},
        // *레*미*레*도*레*미*도
        {D2,N8}, {E2,N8}, {D2,N8}, {C2,N8}, {D2,N8}, {E2,N8}, {C2,N8},
        // 솔#파솔라*도-
        {G1_,N8}, {F1,N8}, {G1,N8}, {A1,N8}, {C2,N8}, {C2,N16},
        // 솔라*도라
        {G1,N8}, {A1,N8}, {C2,N8}, {A1,N8},
        // 솔#파솔라*도라
        {G1_,N8}, {F1,N8}, {G1,N8}, {A1,N8}, {C2,N8}, {A1,N8}
    
    };
	const char * note_name[] = {"C1", "C1#", "D1", "D1#", "E1", "F1", "F1#", "G1", "G1#", "A1", "A1#", "B1", "C2", "C2#", "D2", "D2#", "E2", "F2", "F2#", "G2", "G2#", "A2", "A2#", "B2"};
    const int BGM_LEN = sizeof(BGM_melody) / sizeof(BGM_melody[0]);
	System_Init();
	Uart_Printf("Frog Prince,Protect the stars\n");

	Lcd_Init(DIPLAY_MODE);
    TIM3_Out_Init();
	Jog_Poll_Init();
	Jog_ISR_Enable(1);
	Uart1_RX_Interrupt_Enable(1);
	stage = 1;
	int a = 0;
	int i=0;
    int j,e=0,d,c=0;
	int b=0;
    int f=0;
	int x=0,y=0;
	int freeze_mode=0;
	int boss_b=0;
    int t=0;
	gage = 0;
    int stop =0;
    Move_key = 0;
    frog_hp = 5;
    int cheat =0;
    int cool_time =0;
    int cool=0;
    int Reload = 3;
    int BGM = 1;
    
    
	for(;;)
	{
		Lcd_Printf(70,30,RED,0,2,2,"Frog Prince");
		Lcd_Printf(20,80,RED,0,2,2,"Protect the stars");
		Lcd_Printf(90,200,RED,0,1,1,"Press the key SW1");
        draw_image(100,130, &b1);
        Lcd_Printf(230, 0, RED, BLACK, 1, 1, "Cheat :%2d", cheat);
        
        if(Jog_key==4)
        {
            cheat++;
        }

        if((cheat>=1)&&(cheat<6)) BGM=0;
        if(cheat>=4) frog_hp = 10000;

        
		if(Jog_key==5) break;
        Jog_key=0;
	}
    if(BGM)
    {
    Buzzer_Beep(BGM_melody[t][0], BGM_melody[t][1]);
	t++;
    }
	for(;;)
	{
		Game_Init();
		
		TIM4_Repeat_Interrupt_Enable(1, TIMER_PERIOD*10);
		SysTick_Interrupt_Enable(300); 
		Lcd_Printf(0,0,RED,BLACK,1,1,"score : %d", score);

		for(;;)
		{
			int game_over = 0;
            int rld,u;
			if(Jog_key_in) 
			{
                rld= Macro_Extract_Area(~GPIOB->IDR,0x7,5);
                u= Macro_Check_Bit_Clear(GPIOB->IDR,3);
				//Uart_Printf(" %d\n",Jog_key);
				
                //frog.ci = BACK_COLOR;
				//Draw_Object(&frog);
				
                if(Jog_key == 5)
				{
					x=1;
				}
				
                if(Jog_key == 4)
				{
					y=1;
				}
				if((Jog_key==5)&&(cool>1))
                {
                    Fire_Bullet_From_Frog();
                    
                    cool=0;
                }
                
                
                if((rld==0)&&(u==0)) Move_key=0;

				//Frog_Move(Jog_key);
				//frog.ci = FROG_COLOR;
				//Draw_Object(&frog);
				Jog_key_in = 0;
			}

			if(SysTick_Flag)
			{
				a++;
				b++;
				d++;
				e++;
              
                cool++;
                     
				if(d>=1)
				{
					if((freeze_mode==0)&&(x==1)&&(y==1)&&(gage>=10))
					{
						gage-=10;
						freeze_mode = 1;
						Uart_Printf("freeze mode On\n");
                        Lcd_Printf(90,0,GREEN,BLACK,1,1,"Freeze Mode On!");
					}
					d=0;
					x=0;
					y=0;
				}

				if(freeze_mode)
				{
					c++;
				}

				if(c==10)
				{
					Uart_Printf("freeze mode Off\n");
					freeze_mode=0;
                    Lcd_Printf(90,0,BLACK,BLACK,1,1,"                 ");
					c=0;
				}

                if(stage==1)
                {
				    if((a==13))
				    {
				    	Spawn_New_UFO();
				    	a=0;
				    }
				
				    if (boss.active)
				    {
                        boss_b++;
                        if(boss_b==7)
                        {
                            Boss_Fire_Missile(boss.x, boss.y);
                            boss_b = 0;
                        }
				    }

                    if(b==18)
                    {
                        for (i = 0; i < MAX_UFO; i++) {
                            if (ufos[i].active) {
                                UFO_Fire_Bullets(ufos[i].x, ufos[i].y);
                            }
                        }
                        b=0;
                    }

                    if((e==150)) 
                    {
                        Create_BossUFO();
                    }
                }

                if(stage==2)
                {
                    if(f==0)
                    {
                        a=0;
                        b=0;
                        d=0;
                        e=0;
                        f++;
                    }

                    if((a==8))
				    {
				    	Spawn_New_UFO();
				    	a=0;
				    }
				
				    if (boss.active)
				    {
                        boss_b++;
                        if(boss_b==7)
                        {
                            Boss_Fire_Missile(boss.x, boss.y);
                            boss_b = 0;
                        }
				    }

                    if(b==10)
                    {
                        int i;
                        for (i = 0; i < MAX_UFO; i++) {
                            if (ufos[i].active) {
                                UFO_Fire_Bullets(ufos[i].x, ufos[i].y);
                            }
                        }
                        b=0;
                    }

                    if((e==150)) 
                    {
                        Create_BossUFO();
                        boss.hp = 20;
                    }
                }

                if(stage==3)
                {
                    if(f==1)
                    {
                        a=0;
                        b=0;
                        d=0;
                        e=0;
                        f++;
                    }

                    if((a==6))
				    {
				    	Spawn_New_UFO();
				    	a=0;
				    }
				
				    if (boss.active)
				    {
                        boss_b++;
                        if(boss_b==4)
                        {
                            Boss_Fire_Missile(boss.x, boss.y);
                            boss_b = 0;
                        }
				    }

                    if(b==8)
                    {
                        int i;
                        for (i = 0; i < MAX_UFO; i++) {
                            if (ufos[i].active) {
                                UFO_Fire_Bullets(ufos[i].x, ufos[i].y);
                            }
                        }
                        b=0;
                    }

                    if((e==150)) 
                    {
                        Create_BossUFO();
                        boss.hp = 30;
                    }
                }
                if(stage>=4)
                {
                    Lcd_Draw_Back_Color(BLACK);
                    Lcd_Printf(30,40,RED,BLACK,2,2,"Enemy UFO Clear");
                    Lcd_Printf(30,80,RED,BLACK,2,2,"Love And Peace");

                    draw_image(100,140, &clear0);

                    while(Jog_key!=4);
                    while(Jog_key!=5);
                    while(Jog_key!=3);
                }

				SysTick_Flag = 0;
			}
			if(TIM2_Expired)
			{
                if(BGM)
                {
                
                TIM3_Out_Stop();
                
                Buzzer_Beep(BGM_melody[t][0], BGM_melody[t][1]);
                //music = 1;
                t++;    
                //music=0;
                if (t >= BGM_LEN) t=0;
                }
                TIM2_Expired =0;
			}

			if(TIM4_expired)
			{
                if(!stop)
                {
                    Move_And_Draw_Bullets(bullets, MAX_BULLETS);
                    Check_Bullet_UFO_Collisions(bullets, MAX_BULLETS, ufos, MAX_UFO, &boss,boss_missiles, MAX_BOSS_MISSILES);
                    Check_Frog_Item_Collision_and_Apply(items, MAX_ITEMS);
                    Move_And_Draw_Items(items, MAX_ITEMS);
                    if(!freeze_mode)
                    {
                        Move_And_Draw_UFOs(ufos, MAX_UFO);
                        Move_And_Draw_UFO_Bullets(ufo_bullets, MAX_UFO_BULLETS);
                        Move_And_Draw_BossUFO(&boss); 
                        Move_And_Draw_BossMissiles(boss_missiles, MAX_BOSS_MISSILES);
                    }
                    if(stage<=3)
                    {
                    Lcd_Printf(0,0,RED,BLACK,1,1,"score : %d", score);
                    Lcd_Printf(0, 220, RED, BLACK, 1, 1, "HP : %d", frog_hp);
                    Lcd_Printf(230, 220, RED, BLACK, 1, 1, "SP Gage :%2d", gage);
                    Lcd_Printf(230, 0, RED, BLACK, 1, 1, "Stage :%2d", stage);

                    }
                    if(Move_key>=1)
                    {
                        frog.ci = BACK_COLOR;
                        Draw_Object(&frog);

                        Frog_Move(Jog_key);

                        frog.ci = FROG_COLOR;
                        draw_image(frog.x, frog.y, &img2);
                    }
                }
                if(frog_hp<=0)
                {
                    Move_key=0;
                    stop=1;
                    TIM4_Repeat_Interrupt_Enable(0, 0);
                    Uart_Printf("Game Over\n");
                    Uart_Printf("SW0 : New Game\n");
                    Uart_Printf("SW1 : Continue Game\n");

                    while(!((Jog_key==5)||(Jog_key==4)));
                    //Jog_Wait_Key_Pressed();
                    //Jog_Wait_Key_Released();
                    if(Jog_key==5) 
                    {
                        Uart_Printf("Continue\n");
                        game_over=0;
                        stop=0;
                        frog_hp=5;
                        bullet_powerup_level=0;
                    }
                    if(Jog_key==4) 
                    {
                        Uart_Printf("New Game\n");
                        Lcd_Draw_Back_Color(WHITE);
                        Clear_All_UFO_and_Bullets();
                        a=0;
                        b=0;
                        d=0;
                        e=0;
                        f=0;
                        score = 0;
                        gage = 0;
                        stage=1;
                        stop=0;
                        frog_hp=5;
                        bullet_powerup_level=0;
                        items[i].active =0;
                    }
                    Uart_Printf("Game Start\n");
                    break;
                }



				TIM4_expired = 0;
            }
               



		
            #if 0
			if(frog_hp<=0)
			{
                Move_key=0;
                stop=1;
				TIM4_Repeat_Interrupt_Enable(0, 0);
				Uart_Printf("Game Over\n");
                Uart_Printf("SW0 : New Game\n");
                Uart_Printf("SW1 : Continue Game\n");

				Jog_Wait_Key_Pressed();
				Jog_Wait_Key_Released();
                if(Jog_key==5) 
                {
                    Uart_Printf("Continue\n");
                    game_over=0;
                    stop=0;
                }
                if(Jog_key==4) 
                {
                    Uart_Printf("New Game\n");
                    Lcd_Draw_Back_Color(WHITE);
                    Clear_All_UFO_and_Bullets();
                    a=0;
                    b=0;
                    d=0;
                    e=0;
                    f=0;
                    score = 0;
                    gage = 0;
                    stage=1;
                    stop=0;
                }
				Uart_Printf("Game Start\n");
				break;
			}
                #endif
		}
	}
}

